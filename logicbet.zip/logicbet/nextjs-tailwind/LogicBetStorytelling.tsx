"use client";

import React from "react";

/* ============================================================================
   1. CARDLESS VERTICAL 3-POINT ROADMAP WITH NATURAL BACKLIGHTING (ACT 02)
   ============================================================================ */
const ROADMAP_STEPS = [
  {
    num: "01",
    title: "Mathematical Calculations for Sports Betting",
  },
  {
    num: "02",
    title: "We Do Daily Analysis to Capital",
  },
  {
    num: "03",
    title: "We Focus on Long Run, Not Short",
  },
];

export function AboutPureRoadmap() {
  return (
    <div className="relative mx-auto inline-flex flex-col items-start gap-5 py-2">
      {/* Natural Ambient Backlight Behind the Words */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -inset-x-12 -inset-y-6 rounded-full bg-[radial-gradient(ellipse_at_center,rgba(25,245,163,0.16)_0%,rgba(155,216,255,0.14)_45%,transparent_75%)] blur-2xl"
      />

      {/* Vertical Connecting Line */}
      <div
        aria-hidden="true"
        className="absolute bottom-4 left-[15px] top-4 w-0.5 bg-gradient-to-b from-[#19F5A3] via-[#9BD8FF] to-[#19F5A3] shadow-[0_0_12px_#19F5A3]"
      />

      {ROADMAP_STEPS.map((step) => (
        <div key={step.num} className="relative z-10 flex items-center gap-4 text-left">
          <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-[#19F5A3] bg-[#041024] font-mono text-xs font-bold text-[#19F5A3] shadow-[0_0_0_4px_rgba(25,245,163,0.14),0_0_18px_rgba(25,245,163,0.55)]">
            {step.num}
          </span>
          <h3 className="text-base font-bold text-white drop-shadow-[0_0_20px_rgba(155,216,255,0.45)] sm:text-lg">
            {step.title}
          </h3>
        </div>
      ))}
    </div>
  );
}
