(() => {
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isDesktop = () => window.innerWidth >= 1024;

  /* ============================================================
     1. UNIFIED 3D SHADED STADIUM, VOLUMETRIC STARBALL & UPRIGHT GOAL
     ============================================================ */
  const canvas = document.getElementById('universeCanvas');
  const progressBar = document.getElementById('scrollProgressBar');
  const navbar = document.getElementById('navbar');

  let targetStoryProgress = 0;
  let currentStoryProgress = 0;
  let targetGlobalProgress = 0;
  let currentGlobalProgress = 0;

  function clamp(val, min, max) {
    return Math.max(min, Math.min(max, val));
  }

  function smoothstep(e0, e1, x) {
    const t = clamp((x - e0) / (e1 - e0), 0, 1);
    return t * t * (3 - 2 * t);
  }

  if (canvas) {
    const ctx = canvas.getContext('2d');
    let W = 0;
    let H = 0;
    let dpr = Math.min(window.devicePixelRatio || 1, 2);

    function resizeCanvas() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = window.innerWidth;
      H = window.innerHeight;
      canvas.width = Math.max(1, Math.floor(W * dpr));
      canvas.height = Math.max(1, Math.floor(H * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const phi = (1 + Math.sqrt(5)) / 2;
    const starCenters = [
      [-1, phi, 0], [1, phi, 0], [-1, -phi, 0], [1, -phi, 0],
      [0, -1, phi], [0, 1, phi], [0, -1, -phi], [0, 1, -phi],
      [phi, 0, -1], [phi, 0, 1], [-phi, 0, -1], [-phi, 0, 1]
    ].map(([x, y, z]) => {
      const l = Math.hypot(x, y, z);
      return [x / l, y / l, z / l];
    });

    function buildStarOnSphere(normal, outerR = 0.44, innerR = 0.19) {
      const up = Math.abs(normal[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
      let ux = up[1] * normal[2] - up[2] * normal[1];
      let uy = up[2] * normal[0] - up[0] * normal[2];
      let uz = up[0] * normal[1] - up[1] * normal[0];
      const ul = Math.hypot(ux, uy, uz);
      ux /= ul; uy /= ul; uz /= ul;

      const vx = normal[1] * uz - normal[2] * uy;
      const vy = normal[2] * ux - normal[0] * uz;
      const vz = normal[0] * uy - normal[1] * ux;

      const pts = [];
      for (let i = 0; i < 10; i++) {
        const angle = (i * Math.PI) / 5 - Math.PI / 2;
        const r = i % 2 === 0 ? outerR : innerR;
        const dx = Math.cos(angle) * r;
        const dy = Math.sin(angle) * r;
        const px = normal[0] + ux * dx + vx * dy;
        const py = normal[1] + uy * dx + vy * dy;
        const pz = normal[2] + uz * dx + vz * dy;
        const pl = Math.hypot(px, py, pz);
        pts.push([px / pl, py / pl, pz / pl]);
      }
      return pts;
    }

    const stars3D = starCenters.map((center) => ({
      center,
      points: buildStarOnSphere(center)
    }));

    const pitchCenterZ = 52;
    const goalLineZ = 88;
    const goalDepthZ = 93.5;

    const floodlightAngles = [
      Math.PI * 0.20, Math.PI * 0.35, Math.PI * 0.47,
      Math.PI * 0.53, Math.PI * 0.65, Math.PI * 0.80
    ];

    const stadiumParticles = Array.from({ length: 50 }, (_, i) => {
      const seed1 = Math.sin(i * 12.9898) * 43758.5453;
      const seed2 = Math.sin(i * 78.233) * 43758.5453;
      const seed3 = Math.sin(i * 39.425) * 43758.5453;
      const r1 = seed1 - Math.floor(seed1);
      const r2 = seed2 - Math.floor(seed2);
      const r3 = seed3 - Math.floor(seed3);
      return {
        x: (r1 - 0.5) * 44,
        y: 0.6 + r2 * 14,
        z: 16 + r3 * 74,
        size: 1.0 + (i % 4) * 0.45,
        phase: i * 0.73,
        emerald: i % 3 !== 0
      };
    });

    let pointerX = 0;
    let pointerY = 0;
    window.addEventListener('pointermove', (e) => {
      pointerX = (e.clientX / Math.max(1, W) - 0.5) * 0.35;
      pointerY = (e.clientY / Math.max(1, H) - 0.5) * 0.25;
    }, { passive: true });

    function rotatePt([x, y, z], rx, ry) {
      const cosY = Math.cos(ry), sinY = Math.sin(ry);
      const cosX = Math.cos(rx), sinX = Math.sin(rx);
      const x1 = x * cosY - z * sinY;
      const z1 = x * sinY + z * cosY;
      const y2 = y * cosX - z1 * sinX;
      const z2 = y * sinX + z1 * cosX;
      return [x1, y2, z2];
    }

    function renderUniverse(now) {
      const time = (now || 0) * 0.001;
      currentStoryProgress += (targetStoryProgress - currentStoryProgress) * 0.12;
      currentGlobalProgress += (targetGlobalProgress - currentGlobalProgress) * 0.12;

      const s = clamp(currentStoryProgress, 0, 1);
      const g = clamp(currentGlobalProgress, 0, 1);
      const isMobile = W < 768;

      ctx.clearRect(0, 0, W, H);

      // ====================================================
      // LAYER 1: UPRIGHT 3D STADIUM, TURF & GOAL ZOOM
      // ====================================================
      const stadiumVisibility = smoothstep(0.05, 0.30, s);
      const storyWalk = smoothstep(0.08, 0.95, s);
      const postStoryProgress = smoothstep(0.36, 0.98, g);
      const goalZoomProgress = smoothstep(0.68, 0.98, g);

      const camZ = 8 + storyWalk * 20 + postStoryProgress * 24 + goalZoomProgress * 21.5;
      const camY = 2.35 - pointerY * 0.25;
      const camX = pointerX * (0.9 - goalZoomProgress * 0.5);

      const focal = Math.min(W, H) * (isMobile ? 0.86 : 0.96) * (1 + goalZoomProgress * 0.22);
      const cx = W * 0.5;
      const horizonY = H * (isMobile ? 0.58 : 0.55);
      const nearZ = 1.2;

      if (stadiumVisibility > 0.01) {
        ctx.save();
        ctx.globalAlpha = stadiumVisibility;

        function projectRaw(wx, wy, wz) {
          const dz = wz - camZ;
          if (dz < nearZ) return null;
          const sc = focal / dz;
          return [cx + (wx - camX) * sc, horizonY - (wy - camY) * sc, sc, dz];
        }

        function clipAndProjectSegment(p1, p2) {
          let x1 = p1[0] - camX, y1 = p1[1] - camY, z1 = p1[2] - camZ;
          let x2 = p2[0] - camX, y2 = p2[1] - camY, z2 = p2[2] - camZ;
          if (z1 < nearZ && z2 < nearZ) return null;
          if (z1 < nearZ) {
            const t = (nearZ - z1) / (z2 - z1);
            x1 += (x2 - x1) * t;
            y1 += (y2 - y1) * t;
            z1 = nearZ;
          } else if (z2 < nearZ) {
            const t = (nearZ - z2) / (z1 - z2);
            x2 += (x1 - x2) * t;
            y2 += (y1 - y2) * t;
            z2 = nearZ;
          }
          const s1 = focal / z1;
          const s2 = focal / z2;
          return [
            cx + x1 * s1,
            horizonY - y1 * s1,
            cx + x2 * s2,
            horizonY - y2 * s2
          ];
        }

        function strokeSegment3D(p1, p2) {
          const seg = clipAndProjectSegment(p1, p2);
          if (!seg) return;
          ctx.moveTo(seg[0], seg[1]);
          ctx.lineTo(seg[2], seg[3]);
        }

        function fillPolygon3D(worldPts, fillStyle) {
          const camPts = worldPts.map((pt) => [pt[0] - camX, pt[1] - camY, pt[2] - camZ]);
          const clipped = [];
          for (let i = 0; i < camPts.length; i++) {
            const curr = camPts[i];
            const prev = camPts[(i + camPts.length - 1) % camPts.length];
            const currIn = curr[2] >= nearZ;
            const prevIn = prev[2] >= nearZ;

            if (currIn !== prevIn) {
              const t = (nearZ - prev[2]) / (curr[2] - prev[2]);
              clipped.push([
                prev[0] + (curr[0] - prev[0]) * t,
                prev[1] + (curr[1] - prev[1]) * t,
                nearZ
              ]);
            }
            if (currIn) {
              clipped.push(curr);
            }
          }
          if (clipped.length < 3) return;

          ctx.fillStyle = fillStyle;
          ctx.beginPath();
          for (let i = 0; i < clipped.length; i++) {
            const [vx, vy, vz] = clipped[i];
            const sc = focal / vz;
            const sx = cx + vx * sc;
            const sy = horizonY - vy * sc;
            if (i === 0) ctx.moveTo(sx, sy);
            else ctx.lineTo(sx, sy);
          }
          ctx.closePath();
          ctx.fill();
        }

        // 1. Full-Width Ground Horizon Turf Base
        const turfBaseGrad = ctx.createLinearGradient(0, horizonY, 0, H);
        turfBaseGrad.addColorStop(0, 'rgba(4, 18, 22, 0.85)');
        turfBaseGrad.addColorStop(0.35, 'rgba(6, 32, 28, 0.65)');
        turfBaseGrad.addColorStop(1, 'rgba(2, 10, 18, 0.92)');
        ctx.fillStyle = turfBaseGrad;
        ctx.fillRect(0, horizonY, W, H - horizonY);

        // 2. Atmospheric Stadium Horizon Glow behind the Goal
        const goalCenterProj = projectRaw(0, 3.6, goalLineZ) || [cx, horizonY - 20, 10, 12];
        const glowRadius = Math.max(W, H) * (0.38 + goalZoomProgress * 0.22);
        const bowlGlow = ctx.createRadialGradient(
          goalCenterProj[0], goalCenterProj[1], glowRadius * 0.04,
          goalCenterProj[0], goalCenterProj[1], glowRadius
        );
        bowlGlow.addColorStop(0, `rgba(25, 245, 163, ${(0.20 + goalZoomProgress * 0.14).toFixed(3)})`);
        bowlGlow.addColorStop(0.45, 'rgba(10, 34, 78, 0.32)');
        bowlGlow.addColorStop(1, 'rgba(2, 6, 17, 0)');
        ctx.fillStyle = bowlGlow;
        ctx.fillRect(0, 0, W, H);

        // 3. Shaded Stadium Grandstand Tiers
        const bowlFade = 1 - goalZoomProgress * 0.35;
        if (bowlFade > 0.05) {
          ctx.save();
          ctx.globalAlpha = stadiumVisibility * bowlFade;
          const tierHeights = [
            { yBot: 0.0, yTop: 6.0, rx: 38, rz: 44, fill: 'rgba(6, 15, 36, 0.72)', rim: 'rgba(25, 245, 163, 0.25)' },
            { yBot: 6.4, yTop: 13.0, rx: 44, rz: 50, fill: 'rgba(8, 20, 48, 0.60)', rim: 'rgba(155, 216, 255, 0.22)' },
            { yBot: 13.4, yTop: 20.0, rx: 50, rz: 56, fill: 'rgba(10, 26, 60, 0.48)', rim: 'rgba(25, 245, 163, 0.30)' }
          ];
          const arcSegs = 24;
          for (const tier of tierHeights) {
            for (let i = 0; i < arcSegs; i++) {
              const a1 = Math.PI * (0.12 + (i / arcSegs) * 0.76);
              const a2 = Math.PI * (0.12 + ((i + 1) / arcSegs) * 0.76);
              const x1 = Math.cos(a1) * tier.rx;
              const z1 = pitchCenterZ + Math.sin(a1) * tier.rz;
              const x2 = Math.cos(a2) * tier.rx;
              const z2 = pitchCenterZ + Math.sin(a2) * tier.rz;
              fillPolygon3D(
                [
                  [x1, tier.yBot, z1],
                  [x2, tier.yBot, z2],
                  [x2, tier.yTop, z2],
                  [x1, tier.yTop, z1]
                ],
                tier.fill
              );
            }
            ctx.lineWidth = 1.4;
            ctx.strokeStyle = tier.rim;
            ctx.beginPath();
            for (let i = 0; i < arcSegs; i++) {
              const a1 = Math.PI * (0.12 + (i / arcSegs) * 0.76);
              const a2 = Math.PI * (0.12 + ((i + 1) / arcSegs) * 0.76);
              strokeSegment3D(
                [Math.cos(a1) * tier.rx, tier.yTop, pitchCenterZ + Math.sin(a1) * tier.rz],
                [Math.cos(a2) * tier.rx, tier.yTop, pitchCenterZ + Math.sin(a2) * tier.rz]
              );
            }
            ctx.stroke();
          }

          floodlightAngles.forEach((baseAngle, idx) => {
            const lx = Math.cos(baseAngle) * 48;
            const ly = 21.5;
            const lz = pitchCenterZ + Math.sin(baseAngle) * 56;
            const src = projectRaw(lx, ly, lz);
            if (!src) return;
            const sweep = Math.sin(time * 0.6 + idx * 1.1) * 5;
            const target = projectRaw(sweep * 0.6, 0, goalLineZ - 6);
            if (!target) return;

            const spread = Math.max(36, W * 0.08);
            const coneGrad = ctx.createLinearGradient(src[0], src[1], target[0], target[1]);
            const isEmerald = idx % 2 === 0;
            coneGrad.addColorStop(0, isEmerald ? 'rgba(25, 245, 163, 0.16)' : 'rgba(155, 216, 255, 0.16)');
            coneGrad.addColorStop(0.65, 'rgba(155, 216, 255, 0.03)');
            coneGrad.addColorStop(1, 'rgba(2, 6, 17, 0)');

            ctx.fillStyle = coneGrad;
            ctx.beginPath();
            ctx.moveTo(src[0] - 3, src[1]);
            ctx.lineTo(src[0] + 3, src[1]);
            ctx.lineTo(target[0] + spread, target[1]);
            ctx.lineTo(target[0] - spread, target[1]);
            ctx.closePath();
            ctx.fill();

            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(src[0], src[1], 2.4, 0, Math.PI * 2);
            ctx.fill();
          });
          ctx.restore();
        }

        // 4. Mowed Emerald Turf Stripes
        const stripDepth = 4;
        for (let z = 12; z < goalLineZ; z += stripDepth) {
          const isEven = ((z - 12) / stripDepth) % 2 === 0;
          const stripeColor = isEven
            ? 'rgba(14, 58, 46, 0.42)'
            : 'rgba(8, 38, 32, 0.38)';
          fillPolygon3D(
            [
              [-32, 0, z],
              [32, 0, z],
              [32, 0, z + stripDepth],
              [-32, 0, z + stripDepth]
            ],
            stripeColor
          );
        }

        // 5. Pitch Markings
        ctx.lineWidth = 1.6;
        ctx.strokeStyle = 'rgba(220, 245, 255, 0.38)';
        ctx.beginPath();
        strokeSegment3D([-26, 0, goalLineZ], [26, 0, goalLineZ]);
        strokeSegment3D([-26, 0, 16], [-26, 0, goalLineZ]);
        strokeSegment3D([26, 0, 16], [26, 0, goalLineZ]);
        strokeSegment3D([-26, 0, pitchCenterZ], [26, 0, pitchCenterZ]);
        strokeSegment3D([-14.5, 0, goalLineZ], [-14.5, 0, goalLineZ - 14]);
        strokeSegment3D([-14.5, 0, goalLineZ - 14], [14.5, 0, goalLineZ - 14]);
        strokeSegment3D([14.5, 0, goalLineZ - 14], [14.5, 0, goalLineZ]);
        strokeSegment3D([-7.5, 0, goalLineZ], [-7.5, 0, goalLineZ - 5]);
        strokeSegment3D([-7.5, 0, goalLineZ - 5], [7.5, 0, goalLineZ - 5]);
        strokeSegment3D([7.5, 0, goalLineZ - 5], [7.5, 0, goalLineZ]);
        ctx.stroke();

        const penSpot = projectRaw(0, 0, goalLineZ - 9.5);
        if (penSpot) {
          ctx.fillStyle = 'rgba(25, 245, 163, 0.72)';
          ctx.beginPath();
          ctx.arc(penSpot[0], penSpot[1], Math.max(2, penSpot[2] * 0.12), 0, Math.PI * 2);
          ctx.fill();
        }

        // 6. Upright 3D Football Goal
        const goalW = isMobile ? 6.8 : 8.6;
        const goalH = 6.2;

        fillPolygon3D(
          [
            [-goalW, 0, goalLineZ],
            [goalW, 0, goalLineZ],
            [goalW, goalH, goalLineZ],
            [-goalW, goalH, goalLineZ]
          ],
          `rgba(25, 245, 163, ${(0.04 + goalZoomProgress * 0.07).toFixed(3)})`
        );

        const netAlpha = 0.22 + goalZoomProgress * 0.34;
        ctx.lineWidth = 0.95 + goalZoomProgress * 0.35;
        ctx.strokeStyle = `rgba(185, 232, 255, ${netAlpha.toFixed(3)})`;
        ctx.beginPath();

        const netCols = 14;
        const netRows = 7;
        for (let c = 0; c <= netCols; c++) {
          const nx = -goalW + (c / netCols) * (goalW * 2);
          const wave = Math.sin(time * 2.0 + c * 0.5) * 0.14;
          strokeSegment3D([nx, 0, goalDepthZ + wave], [nx, goalH, goalDepthZ + wave]);
          strokeSegment3D([nx, goalH, goalLineZ], [nx, goalH, goalDepthZ + wave]);
        }

        for (let r = 0; r <= netRows; r++) {
          const ny = (r / netRows) * goalH;
          const wave = Math.cos(time * 1.8 + r * 0.6) * 0.14;
          strokeSegment3D([-goalW, ny, goalDepthZ + wave], [goalW, ny, goalDepthZ + wave]);
          strokeSegment3D([-goalW, ny, goalLineZ], [-goalW, ny, goalDepthZ + wave]);
          strokeSegment3D([goalW, ny, goalLineZ], [goalW, ny, goalDepthZ + wave]);
        }

        ctx.lineWidth = 1.6;
        ctx.strokeStyle = `rgba(25, 245, 163, ${(0.38 + goalZoomProgress * 0.32).toFixed(3)})`;
        ctx.beginPath();
        strokeSegment3D([-goalW, goalH, goalLineZ], [-goalW, goalH, goalDepthZ]);
        strokeSegment3D([goalW, goalH, goalLineZ], [goalW, goalH, goalDepthZ]);
        strokeSegment3D([-goalW, goalH, goalDepthZ], [-goalW, 0, goalDepthZ]);
        strokeSegment3D([goalW, goalH, goalDepthZ], [goalW, 0, goalDepthZ]);
        strokeSegment3D([-goalW, 0, goalDepthZ], [goalW, 0, goalDepthZ]);
        ctx.stroke();

        ctx.save();
        ctx.shadowColor = 'rgba(25, 245, 163, 0.85)';
        ctx.shadowBlur = 14 + goalZoomProgress * 16;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        ctx.lineWidth = 4.0 + goalZoomProgress * 5.0;
        ctx.strokeStyle = 'rgba(25, 245, 163, 0.78)';
        ctx.beginPath();
        strokeSegment3D([-goalW, 0, goalLineZ], [-goalW, goalH, goalLineZ]);
        strokeSegment3D([-goalW, goalH, goalLineZ], [goalW, goalH, goalLineZ]);
        strokeSegment3D([goalW, goalH, goalLineZ], [goalW, 0, goalLineZ]);
        ctx.stroke();

        ctx.lineWidth = 2.2 + goalZoomProgress * 2.6;
        ctx.strokeStyle = '#ffffff';
        ctx.beginPath();
        strokeSegment3D([-goalW, 0, goalLineZ], [-goalW, goalH, goalLineZ]);
        strokeSegment3D([-goalW, goalH, goalLineZ], [goalW, goalH, goalLineZ]);
        strokeSegment3D([goalW, goalH, goalLineZ], [goalW, 0, goalLineZ]);
        ctx.stroke();
        ctx.restore();

        for (const pt of stadiumParticles) {
          const driftY = Math.sin(time * 0.8 + pt.phase) * 0.45;
          const driftX = Math.cos(time * 0.5 + pt.phase) * 0.35;
          const proj = projectRaw(pt.x + driftX, pt.y + driftY, pt.z);
          if (!proj) continue;
          const [sx, sy, , dz] = proj;
          if (sx < -20 || sx > W + 20 || sy < -20 || sy > H + 20) continue;
          const depthAlpha = clamp((1 - dz / 85) * 0.6, 0.05, 0.6);
          const rad = clamp(pt.size * (22 / Math.max(6, dz)), 0.8, 3.0);
          ctx.fillStyle = pt.emerald
            ? `rgba(25, 245, 163, ${depthAlpha.toFixed(3)})`
            : `rgba(185, 228, 255, ${depthAlpha.toFixed(3)})`;
          ctx.beginPath();
          ctx.arc(sx, sy, rad, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      }

      // ====================================================
      // LAYER 2: VOLUMETRIC 3D SHADED STARBALL (Act 01 Hero -> Enters Stadium)
      // ====================================================
      const globeMorph = smoothstep(0.0, 0.36, s);
      const globeFadeOut = 1 - smoothstep(0.18, 0.40, s);

      if (globeFadeOut > 0.01) {
        const globeX = W * 0.5;
        const globeY = H * 0.5;
        const baseRadius = Math.min(W, H) * (isMobile ? 0.28 : 0.25);
        const radius = baseRadius * (1 + Math.pow(globeMorph, 1.6) * 3.8);

        const rotY = time * 0.35 + s * 3.2 + pointerX * 0.5;
        const rotX = 0.22 + s * 1.0 + pointerY * 0.4;

        ctx.save();
        ctx.globalAlpha = globeFadeOut;

        const aura = ctx.createRadialGradient(globeX, globeY, radius * 0.2, globeX, globeY, radius * 1.35);
        aura.addColorStop(0, 'rgba(25, 245, 163, 0.16)');
        aura.addColorStop(0.5, 'rgba(12, 34, 78, 0.22)');
        aura.addColorStop(1, 'rgba(2, 6, 17, 0)');
        ctx.fillStyle = aura;
        ctx.beginPath();
        ctx.arc(globeX, globeY, radius * 1.35, 0, Math.PI * 2);
        ctx.fill();

        const sphereGrad = ctx.createRadialGradient(
          globeX - radius * 0.32,
          globeY - radius * 0.34,
          radius * 0.06,
          globeX,
          globeY,
          radius
        );
        sphereGrad.addColorStop(0, 'rgba(38, 84, 158, 0.55)');
        sphereGrad.addColorStop(0.38, 'rgba(11, 28, 64, 0.68)');
        sphereGrad.addColorStop(0.82, 'rgba(3, 9, 24, 0.86)');
        sphereGrad.addColorStop(1, 'rgba(25, 245, 163, 0.32)');

        ctx.beginPath();
        ctx.arc(globeX, globeY, radius, 0, Math.PI * 2);
        ctx.fillStyle = sphereGrad;
        ctx.fill();
        ctx.lineWidth = 1.8;
        ctx.strokeStyle = 'rgba(25, 245, 163, 0.52)';
        ctx.stroke();
        ctx.clip();

        const projectedStars = stars3D.map((star) => {
          const cRot = rotatePt(star.center, rotX, rotY);
          const ptsRot = star.points.map((pt) => rotatePt(pt, rotX, rotY));
          return { z: cRot[2], cRot, ptsRot };
        }).sort((a, b) => a.z - b.z);

        for (const st of projectedStars) {
          if (st.z < -0.18) continue;
          const light = clamp((st.z + 0.18) * 0.85, 0.08, 0.95);
          ctx.beginPath();
          st.ptsRot.forEach(([px, py], idx) => {
            const sx = globeX + px * radius;
            const sy = globeY + py * radius;
            if (idx === 0) ctx.moveTo(sx, sy);
            else ctx.lineTo(sx, sy);
          });
          ctx.closePath();

          const panelGrad = ctx.createLinearGradient(
            globeX + (st.cRot[0] - 0.25) * radius,
            globeY + (st.cRot[1] - 0.25) * radius,
            globeX + (st.cRot[0] + 0.25) * radius,
            globeY + (st.cRot[1] + 0.25) * radius
          );
          panelGrad.addColorStop(0, `rgba(25, 245, 163, ${(light * 0.34).toFixed(3)})`);
          panelGrad.addColorStop(1, `rgba(12, 36, 78, ${(light * 0.62).toFixed(3)})`);

          ctx.fillStyle = panelGrad;
          ctx.fill();
          ctx.strokeStyle = `rgba(25, 245, 163, ${(light * 0.72).toFixed(3)})`;
          ctx.lineWidth = 1.25;
          ctx.stroke();
        }

        ctx.restore();
      }

      if (!prefersReducedMotion) {
        requestAnimationFrame(renderUniverse);
      }
    }

    if (prefersReducedMotion) {
      renderUniverse(0);
    } else {
      requestAnimationFrame(renderUniverse);
    }
  }

  /* ============================================================
     2. LENIS SMOOTH SCROLL & TOP PROGRESS BAR
     ============================================================ */
  let lenis = null;
  if (typeof window.Lenis === 'function' && isDesktop() && !prefersReducedMotion) {
    lenis = new window.Lenis({
      duration: 1.15,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true
    });

    function rafLenis(time) {
      lenis.raf(time);
      requestAnimationFrame(rafLenis);
    }
    requestAnimationFrame(rafLenis);

    if (window.ScrollTrigger) {
      lenis.on('scroll', window.ScrollTrigger.update);
    }
  }

  function updateGlobalScrollMetrics() {
    const scrollY = window.scrollY;
    const maxDoc = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    targetGlobalProgress = clamp(scrollY / maxDoc, 0, 1);

    const pct = Math.round(targetGlobalProgress * 100);
    if (progressBar) {
      progressBar.style.width = `${pct}%`;
    }
    if (navbar) {
      navbar.classList.toggle('scrolled', scrollY > 24);
    }
  }

  window.addEventListener('scroll', updateGlobalScrollMetrics, { passive: true });
  updateGlobalScrollMetrics();

  /* ============================================================
     3. WORD SPLITTER FOR ACT 02 ABOUT US HEADLINE
     ============================================================ */
  const manifestoEl = document.getElementById('manifestoText');
  if (manifestoEl) {
    const words = manifestoEl.textContent.trim().split(/\s+/);
    manifestoEl.innerHTML = words.map((w) => `<span class="manifesto-word">${w}</span>`).join(' ');
  }

  /* ============================================================
     4. GSAP SCROLLTRIGGER STORYTELLING TIMELINE (DESKTOP & MOBILE)
     ============================================================ */
  if (window.gsap && window.ScrollTrigger && !prefersReducedMotion) {
    const gsap = window.gsap;
    const ScrollTrigger = window.ScrollTrigger;
    gsap.registerPlugin(ScrollTrigger);

    const heroLines = document.querySelectorAll('.hero__title .line-inner');
    if (heroLines.length > 0) {
      gsap.from(heroLines, {
        yPercent: 110,
        opacity: 0,
        duration: 1.0,
        stagger: 0.1,
        ease: 'power4.out',
        clearProps: 'transform,opacity'
      });
    }

    const manifestoWords = document.querySelectorAll('.manifesto-word');
    const act02Layer = document.getElementById('act02Layer');
    const mm = gsap.matchMedia();

    // DESKTOP (>= 1024px): Pinned Continuous Camera Flight
    mm.add('(min-width: 1024px)', () => {
      const storyTl = gsap.timeline({
        scrollTrigger: {
          trigger: '#storyStickyStage',
          start: 'top top',
          end: '+=200%',
          scrub: 1,
          pin: true,
          anticipatePin: 1,
          onUpdate: (self) => {
            targetStoryProgress = self.progress;
            if (act02Layer) {
              act02Layer.classList.toggle('is-interactive', self.progress > 0.32);
            }
          }
        }
      });

      storyTl
        .to('#heroContent', {
          y: -80,
          scale: 0.94,
          opacity: 0,
          ease: 'power2.inOut',
          duration: 0.34
        }, 0)
        
        .to('#heroLegendRight', {
          x: 95,
          scale: 1.06,
          opacity: 0,
          ease: 'power2.inOut',
          duration: 0.36
        }, 0)
        .to('#heroTickerRibbon', {
          y: 45,
          opacity: 0,
          ease: 'power2.inOut',
          duration: 0.28
        }, 0)
        .fromTo('#beamLeft', { rotation: -14, opacity: 0.12 }, { rotation: 10, opacity: 0.32, duration: 0.85, ease: 'none' }, 0.15)
        .fromTo('#beamRight', { rotation: 14, opacity: 0.12 }, { rotation: -10, opacity: 0.32, duration: 0.85, ease: 'none' }, 0.15)
        .fromTo('#act02Layer', {
          opacity: 0,
          y: 48
        }, {
          opacity: 1,
          y: 0,
          duration: 0.26,
          ease: 'power3.out'
        }, 0.30)
        .to(manifestoWords, {
          opacity: 1,
          stagger: 0.03,
          duration: 0.30,
          ease: 'none'
        }, 0.33)
        .fromTo('#aboutRoadmap .pure-roadmap__step', {
          y: 24,
          opacity: 0
        }, {
          y: 0,
          opacity: 1,
          stagger: 0.09,
          duration: 0.28,
          ease: 'power2.out'
        }, 0.44)
        .to('#act02Layer', {
          y: -36,
          opacity: 0.15,
          duration: 0.14,
          ease: 'power1.in'
        }, 0.88);
    });

    // MOBILE & TABLET (<= 1023px): Clean Responsive Scroll Scrub
    mm.add('(max-width: 1023px)', () => {
      ScrollTrigger.create({
        trigger: '#storytellingWrapper',
        start: 'top top',
        end: 'bottom bottom',
        scrub: 0.5,
        onUpdate: (self) => {
          targetStoryProgress = self.progress;
        }
      });

      gsap.to('#heroContent', {
        y: -28,
        opacity: 0.2,
        ease: 'none',
        scrollTrigger: {
          trigger: '#act01Layer',
          start: 'top top',
          end: 'bottom top',
          scrub: true
        }
      });

      gsap.fromTo('#manifestoHead', {
        y: 28,
        opacity: 0
      }, {
        y: 0,
        opacity: 1,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: '#act02Layer',
          start: 'top 86%',
          end: 'top 52%',
          scrub: true
        }
      });

      gsap.to(manifestoWords, {
        opacity: 1,
        stagger: 0.03,
        ease: 'none',
        scrollTrigger: {
          trigger: '#act02Layer',
          start: 'top 82%',
          end: 'top 42%',
          scrub: true
        }
      });

      gsap.utils.toArray('#aboutRoadmap .pure-roadmap__step').forEach((step) => {
        gsap.fromTo(step, {
          y: 22,
          opacity: 0
        }, {
          y: 0,
          opacity: 1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: step,
            start: 'top 90%',
            end: 'top 65%',
            scrub: 0.5
          }
        });
      });
    });

    // ACTS 03, 04, 05: Scrubbed Chapter Headers
    gsap.utils.toArray('.story-section').forEach((sec) => {
      const header = sec.querySelector('.story-scrub-header');
      if (header) {
        gsap.fromTo(header, {
          y: 36,
          opacity: 0
        }, {
          y: 0,
          opacity: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: header,
            start: 'top 88%',
            end: 'top 58%',
            scrub: 0.8
          }
        });
      }
    });

    // Architectural Octagon Pricing Cards Entrance
    gsap.utils.toArray('#pricingGrid .octagon-card').forEach((card, i) => {
      gsap.fromTo(card, {
        y: 48,
        opacity: 0,
        scale: 0.92,
        rotateY: i === 0 ? -8 : 8
      }, {
        y: 0,
        opacity: 1,
        scale: 1,
        rotateY: 0,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: card,
          start: 'top 88%',
          end: 'top 56%',
          scrub: 0.8
        }
      });
    });

    // Contact Telegram Wing Card Entrance Inside the Goal
    if (document.querySelector('.tg-wing-card')) {
      gsap.fromTo('.tg-wing-card', {
        y: 44,
        opacity: 0,
        scale: 0.95
      }, {
        y: 0,
        opacity: 1,
        scale: 1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: '.tg-wing-card',
          start: 'top 88%',
          end: 'top 58%',
          scrub: 0.8
        }
      });
    }
  } else {
    document.querySelectorAll('.manifesto-word').forEach((w) => { w.style.opacity = '1'; });
  }

  /* ============================================================
     5. INTERACTIVE 3D TILT & NEON SPOTLIGHT ON ALL TILT CARDS
     ============================================================ */
  const tiltCards = document.querySelectorAll('[data-tilt]');
  if (!prefersReducedMotion) {
    tiltCards.forEach((card) => {
      card.addEventListener('pointermove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const nx = x / Math.max(1, rect.width) - 0.5;
        const ny = y / Math.max(1, rect.height) - 0.5;

        const maxTilt = window.innerWidth < 768 ? 5 : 9;
        card.style.setProperty('--rx', `${(-ny * maxTilt).toFixed(2)}deg`);
        card.style.setProperty('--ry', `${(nx * maxTilt).toFixed(2)}deg`);
        card.style.setProperty('--tz', '6px');
        card.style.setProperty('--mx', `${x.toFixed(0)}px`);
        card.style.setProperty('--my', `${y.toFixed(0)}px`);
      });

      card.addEventListener('pointerleave', () => {
        card.style.setProperty('--rx', '0deg');
        card.style.setProperty('--ry', '0deg');
        card.style.setProperty('--tz', '0px');
      });
    });
  }

  /* ============================================================
     6. NAVIGATION ACTIVE STATE & ANIMATED FULL-SCREEN MOBILE MENU
     ============================================================ */
  const navLinkEls = document.querySelectorAll('.nav-link');
  function setActiveNav(hash) {
    navLinkEls.forEach((link) => {
      link.classList.toggle('active', link.getAttribute('href') === hash);
    });
  }

  window.addEventListener('scroll', () => {
    const sy = window.scrollY;
    const pricingEl = document.getElementById('pricing');
    const mediaEl = document.getElementById('media');
    const contactEl = document.getElementById('contact');

    if (contactEl && sy >= contactEl.offsetTop - window.innerHeight * 0.45) {
      setActiveNav('#contact');
    } else if (mediaEl && sy >= mediaEl.offsetTop - window.innerHeight * 0.45) {
      setActiveNav('#media');
    } else if (pricingEl && sy >= pricingEl.offsetTop - window.innerHeight * 0.45) {
      setActiveNav('#pricing');
    } else if (targetStoryProgress >= 0.32) {
      setActiveNav('#about');
    } else {
      setActiveNav('#home');
    }
  }, { passive: true });

  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');

  function closeMobileMenu() {
    navLinks?.classList.remove('open');
    navToggle?.classList.remove('is-active');
    navToggle?.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('menu-open');
  }

  navToggle?.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    navToggle.classList.toggle('is-active', isOpen);
    navToggle.setAttribute('aria-expanded', String(isOpen));
    document.body.classList.toggle('menu-open', isOpen);
  });

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (e) => {
      const targetId = anchor.getAttribute('href');
      if (!targetId || targetId === '#') return;

      closeMobileMenu();

      if (targetId === '#about' && isDesktop()) {
        e.preventDefault();
        const wrapper = document.getElementById('storytellingWrapper');
        if (wrapper) {
          const destY = wrapper.offsetTop + window.innerHeight * 1.15;
          if (lenis) lenis.scrollTo(destY);
          else window.scrollTo({ top: destY, behavior: 'smooth' });
        }
        return;
      }

      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        e.preventDefault();
        if (lenis) lenis.scrollTo(targetEl, { offset: -10 });
        else targetEl.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  /* ============================================================
     7. ACT 04: 9:16 VERTICAL REEL DECK & TOUCH SWIPE
     ============================================================ */
  const deckStage = document.getElementById('deckStage');
  const deckCards = Array.from(document.querySelectorAll('#deckStage .deck-card'));
  const deckPrevBtn = document.getElementById('deckPrev');
  const deckNextBtn = document.getElementById('deckNext');
  const deckCounterEl = document.getElementById('deckCounter');

  if (deckStage && deckCards.length > 0) {
    const totalCards = deckCards.length;
    const userPaused = new Array(totalCards).fill(false);
    let activeCardIndex = Math.max(0, deckCards.findIndex((c) => c.classList.contains('active')));
    let deckInView = true;

    function syncDeckVideos() {
      deckCards.forEach((card, idx) => {
        const video = card.querySelector('.reel-video');
        const btn = card.querySelector('.video-ctrl-btn');
        if (!video) return;

        if (idx === activeCardIndex && deckInView && !userPaused[idx]) {
          const playPromise = video.play();
          if (playPromise && typeof playPromise.catch === 'function') {
            playPromise.catch(() => {});
          }
          if (btn) btn.textContent = 'Pause';
        } else {
          video.pause();
          if (btn) btn.textContent = 'Play';
        }
      });
    }

    function setActiveDeckCard(nextIndex) {
      activeCardIndex = ((nextIndex % totalCards) + totalCards) % totalCards;
      const prevIdx = (activeCardIndex - 1 + totalCards) % totalCards;
      const nextIdx = (activeCardIndex + 1) % totalCards;

      deckCards.forEach((card, idx) => {
        const isActive = idx === activeCardIndex;
        const isPrev = idx === prevIdx && !isActive;
        const isNext = idx === nextIdx && !isActive;

        card.classList.toggle('active', isActive);
        card.classList.toggle('is-prev', isPrev);
        card.classList.toggle('is-next', isNext);
        card.setAttribute('aria-hidden', String(!isActive));
      });

      if (deckCounterEl) {
        deckCounterEl.textContent = `${String(activeCardIndex + 1).padStart(2, '0')} / ${String(totalCards).padStart(2, '0')}`;
      }

      syncDeckVideos();
    }

    deckCards.forEach((card, idx) => {
      const cardIdx = card.dataset.index !== undefined ? Number(card.dataset.index) : idx;
      const video = card.querySelector('.reel-video');
      const ctrlBtn = card.querySelector('.video-ctrl-btn');

      card.addEventListener('click', (e) => {
        if (e.target.closest('.video-ctrl-btn')) return;
        if (cardIdx !== activeCardIndex) {
          setActiveDeckCard(cardIdx);
        }
      });

      if (ctrlBtn && video) {
        ctrlBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (cardIdx !== activeCardIndex) {
            userPaused[cardIdx] = false;
            setActiveDeckCard(cardIdx);
            return;
          }
          if (video.paused) {
            userPaused[cardIdx] = false;
            const playPromise = video.play();
            if (playPromise && typeof playPromise.catch === 'function') {
              playPromise.catch(() => {});
            }
            ctrlBtn.textContent = 'Pause';
          } else {
            userPaused[cardIdx] = true;
            video.pause();
            ctrlBtn.textContent = 'Play';
          }
        });
      }
    });

    deckPrevBtn?.addEventListener('click', () => setActiveDeckCard(activeCardIndex - 1));
    deckNextBtn?.addEventListener('click', () => setActiveDeckCard(activeCardIndex + 1));

    let touchStartX = 0;
    deckStage.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0]?.clientX || 0;
    }, { passive: true });

    deckStage.addEventListener('touchend', (e) => {
      const touchEndX = e.changedTouches[0]?.clientX || 0;
      const dx = touchEndX - touchStartX;
      if (Math.abs(dx) > 40) {
        if (dx < 0) setActiveDeckCard(activeCardIndex + 1);
        else setActiveDeckCard(activeCardIndex - 1);
      }
    }, { passive: true });

    if ('IntersectionObserver' in window) {
      const deckObserver = new IntersectionObserver(
        (entries) => {
          deckInView = entries[0]?.isIntersecting ?? true;
          syncDeckVideos();
        },
        { threshold: 0.15 }
      );
      deckObserver.observe(deckStage);
    }

    setActiveDeckCard(activeCardIndex);
  }

  /* ============================================================
     8. PRICING MODAL, TELEGRAM LAUNCHER & CLIPBOARD
     ============================================================ */
  const toastEl = document.getElementById('toast');
  let toastTimer = null;
  function showToast(message) {
    if (!toastEl) return;
    toastEl.textContent = message;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2600);
  }

  function copyTextSafe(text, successMsg) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(
        () => showToast(successMsg),
        () => fallbackCopy(text, successMsg)
      );
    } else {
      fallbackCopy(text, successMsg);
    }
  }

  function fallbackCopy(text, successMsg) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
      showToast(successMsg);
    } catch {
      showToast('Copied!');
    }
    document.body.removeChild(ta);
  }

  const subscribeModal = document.getElementById('subscribeModal');
  const closeModalBtn = document.getElementById('closeModalBtn');
  const modalPlanName = document.getElementById('modalPlanName');
  const modalPlanPrice = document.getElementById('modalPlanPrice');
  const modalSubForm = document.getElementById('modalSubForm');

  document.querySelectorAll('.select-plan-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const plan = btn.dataset.plan || 'Pro Trader';
      const price = btn.dataset.price || '$40/mo';
      if (modalPlanName) modalPlanName.textContent = plan;
      if (modalPlanPrice) modalPlanPrice.textContent = price;
      subscribeModal?.classList.add('open');
      subscribeModal?.setAttribute('aria-hidden', 'false');
    });
  });

  function closeSubscribeModal() {
    subscribeModal?.classList.remove('open');
    subscribeModal?.setAttribute('aria-hidden', 'true');
  }

  closeModalBtn?.addEventListener('click', closeSubscribeModal);
  subscribeModal?.addEventListener('click', (e) => {
    if (e.target === subscribeModal) closeSubscribeModal();
  });

  const tgMessageInput = document.getElementById('tgMessageInput');
  const tgLaunchBtn = document.getElementById('tgLaunchBtn');

  function updateTelegramHref(text) {
    if (!tgLaunchBtn) return;
    tgLaunchBtn.href = `https://t.me/share/url?url=${encodeURIComponent('https://instagram.com/logicbet.io')}&text=${encodeURIComponent(text.trim())}`;
  }

  modalSubForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const tgUser = document.getElementById('subTelegram')?.value.trim() || '';
    const plan = modalPlanName?.textContent || 'Pro Trader';
    const price = modalPlanPrice?.textContent || '$40/mo';

    const inviteMsg = `Hey LogicBet Owner! I want to activate ${plan} (${price}). My Telegram: ${tgUser}`;
    if (tgMessageInput) {
      tgMessageInput.value = inviteMsg;
      updateTelegramHref(inviteMsg);
    }

    closeSubscribeModal();
    showToast(`Redirecting to Telegram Desk for ${plan}...`);
    const contactSec = document.getElementById('contact');
    if (contactSec && lenis) lenis.scrollTo(contactSec);
    else contactSec?.scrollIntoView({ behavior: 'smooth' });
  });

  document.getElementById('copyIgBtn')?.addEventListener('click', () => {
    copyTextSafe('logicbet.io', 'Copied @logicbet.io');
  });

  document.querySelectorAll('.tg-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.tg-chip').forEach((c) => c.classList.remove('active'));
      chip.classList.add('active');
      const msg = chip.dataset.msg || '';
      if (tgMessageInput) {
        tgMessageInput.value = msg;
        updateTelegramHref(msg);
      }
    });
  });

  tgMessageInput?.addEventListener('input', () => updateTelegramHref(tgMessageInput.value));

  document.getElementById('copyTgMsgBtn')?.addEventListener('click', () => {
    const text = tgMessageInput?.value.trim() || '';
    copyTextSafe(text, 'Telegram message copied!');
  });
})();
